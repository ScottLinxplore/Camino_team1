import { useState } from "react";
import styles from "./Page4.module.css";
import CheckoutSteps from "./Page4Components/CheckoutSteps";
import PassengerForm from "./Page4Components/PassengerForm";
import ContactForm from "./Page4Components/ContactForm";
import EmergencyContact from "./Page4Components/EmergencyContact";
import FlightInfo from "./Page4Components/FlightInfo";
import AccommodationList from "./Page4Components/AccommodationList";
import AmountSummary from "./Page4Components/AmountSummary";
import { useNavigate } from "react-router-dom";

function App() {
  const navigate = useNavigate();

  const goToPage5 = () => {
    navigate("/page5");
  };
  const goToPage3 = () => {
    navigate("/page3");
  };
  const [count, setCount] = useState(0);
  const [currentStep, setCurrentStep] = useState(2);
  const nextStep = () => {
    if (currentStep < 3) {
      setCurrentStep(currentStep + 1);
    } else {
      setCurrentStep(0);
    }
  };
  // if()
  return (
    <div style={{ width: "90%", margin: "0 auto" }}>
      <h2
        style={{
          fontSize: "60px",
          fontWeight: "bold",
          // margin: 40,
          // border: "2px solid palevioletred",
          width: "100%",
        }}
      >
        填寫旅客資料
      </h2>
      <CheckoutSteps currentStep={currentStep} />
      {/* <button onClick={nextStep}>下一步</button> */}

      <div className={styles["booking-container"]}>
        {/* 左側：填寫資料區 */}
        <div className={styles["booking-left"]}>
          <PassengerForm />
          <ContactForm />
          <EmergencyContact />
        </div>

        {/* 右側：摘要資訊區 */}
        <div className={styles["booking-right"]}>
          <FlightInfo />
          <AccommodationList />
          <AmountSummary totalAmount={25144} onNext={goToPage5} />
        </div>
      </div>
      {/* <div>
        <button onClick={goToPage3}>返回</button>
        <button onClick={goToPage5}>下一頁</button>
      </div> */}
    </div>
  );
}

export default App;
