import AccommodationCard from "./AccommodationCard";
import style from "./AccommodationList.module.css";

export default function AccommodationList() {
  const rooms = [
    {
      name: "Bunk Room",
      date: "2025/7/15 - 2025/8/9",
      day: "24"
    },
    {
      name: "Private Room",
      date: "2025/8/9 - 2025/8/11",
      day: "2"
    },
  ];

  return (
    <div className={style["room-setion"]}>
      <h4>住宿資訊</h4>
      {rooms.map((room, idx) => (
        <AccommodationCard key={idx} {...room} />
      ))}
    </div>
  );
}
