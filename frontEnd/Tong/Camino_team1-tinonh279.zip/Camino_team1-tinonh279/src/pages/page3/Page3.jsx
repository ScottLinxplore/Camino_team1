import { useState } from "react";
import CheckoutSteps from "./Page3Components/CheckoutSteps";
import "./Page3.module.css";
import TripDetails from "./Page3Components/TripDetails";
import TransportInfo from "./Page3Components/TransportInfo";
import AccommodationCard from "./Page3Components/AccommodationCard";
import AmountSummary from "./Page3Components/AmountSummary";
import { useNavigate } from "react-router-dom";

function App() {
  const navigate = useNavigate();

  const goToPage4 = () => {
    navigate("/page4");
  };
  const goToPage2 = () => {
    navigate("/page2");
  };
  // const [count, setCount] = useState(0);
  const [currentStep, setCurrentStep] = useState(1);

  const nextStep = () => {
    if (currentStep < 3) {
      setCurrentStep(currentStep + 1);
    } else {
      setCurrentStep(0);
    }
  };

  return (
    <div style={{ width: "90%", margin: "0 auto" }}>
      <h2
        style={{
          fontSize: "60px",
          fontWeight: "bold",
          // margin: 40,
          // border: "2px solid palevioletred",
          width: "100%",
        }}
      >
        訂單明細
      </h2>
      <CheckoutSteps currentStep={currentStep} />
      <button onClick={nextStep}>下一步</button>
      <div>
        <TripDetails />
      </div>
      <div>
        <TransportInfo />
      </div>
      <div>
        <h3 style={{ fontWeight: "bold" }}>住宿資訊</h3>

        <AccommodationCard
          name="Bunk Room"
          date="2025/7/15 - 2025/8/9"
          day="24"
          price="0"
        />

        <AccommodationCard
          name="Private Room"
          date="2025/8/9 - 2025/8/11"
          day="2"
          price="1000"
        />
      </div>
      <div>
        <AmountSummary totalAmount={25144} onNext={goToPage4} />
      </div>
      {/* <div>
        <button onClick={goToPage2}>返回</button>
        <button onClick={goToPage4}>下一頁</button>
      </div> */}
    </div>
  );
}

export default App;
