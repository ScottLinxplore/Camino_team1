import styles from"./TripDetails.module.css";

export default function TripDetails() {
  return (
    <div className={styles.card}>
      <img src="./project/16.jpg" alt="Trip" className={styles.image} />
      <div className={styles.info}>
        <h3 className={styles.title}>法國之路</h3>
        <p>
          <strong>起點：</strong>法國 聖讓-皮耶-德港
          <br />
          <span> （Saint-Jean-Pied-de-Port）</span>
        </p>
        <p>
          <strong>終點：</strong>西班牙 聖地牙哥-德孔波斯特拉
          <br />
          <span className={styles.span}>（Santiago de Compostela）</span>
        </p>
        <p>
          <strong>日期：</strong>2025/7/15 - 2025/8/11
        </p>
      </div>
    </div>
  );
}
